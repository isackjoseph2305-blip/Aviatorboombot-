package com.aviator.boombot
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.media.projection.MediaProjectionManager

class MainActivity : Activity() {
 private val requestCode = 4102
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState)
  val l=LinearLayout(this).apply { orientation=1; setPadding(28,36,28,28); setBackgroundColor(0xFF101010.toInt()) }
  fun t(s:String,n:Float=17f)=TextView(this).apply { text=s; textSize=n; setTextColor(-1); setPadding(0,12,0,12) }
  l.addView(t("AVIATOR BOOM BOT",26f))
  l.addView(t("BetPawa • Android • Uchambuzi wa historia"))
  l.addView(t("Soma multipliers zinazoonekana kwenye screen, zihifadhi na uonyeshe takwimu. Haitabiri round ijayo."))
  l.addView(Button(this).apply { text="Ruhusu dirisha dogo"; setOnClickListener { if(!Settings.canDrawOverlays(this@MainActivity)) startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:$packageName"))) } })
  l.addView(Button(this).apply { text="Anza kusoma screen"; setOnClickListener { val m=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager; startActivityForResult(m.createScreenCaptureIntent(),requestCode) } })
  setContentView(l)
 }
 @Deprecated("Legacy callback for starter")
 override fun onActivityResult(r:Int,c:Int,d:Intent?) { super.onActivityResult(r,c,d); if(r==requestCode && c==RESULT_OK && d!=null) { startForegroundService(Intent(this,CaptureService::class.java).putExtra("code",c).putExtra("data",d)) } }
}