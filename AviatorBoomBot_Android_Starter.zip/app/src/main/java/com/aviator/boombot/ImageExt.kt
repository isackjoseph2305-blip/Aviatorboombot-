package com.aviator.boombot
import android.graphics.Bitmap
import android.media.Image
fun Image.toBitmapCompat():Bitmap {
 val p=planes[0]; val b=p.buffer; val stride=p.pixelStride; val padding=p.rowStride-stride*width
 val full=Bitmap.createBitmap(width+padding/stride,height,Bitmap.Config.ARGB_8888); full.copyPixelsFromBuffer(b)
 val out=Bitmap.createBitmap(full,0,0,width,height); full.recycle(); return out
}