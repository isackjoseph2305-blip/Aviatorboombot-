package com.aviator.boombot
import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService:Service() {
 private var projection:MediaProjection?=null
 private var display:VirtualDisplay?=null
 private var reader:ImageReader?=null
 private var panel:TextView?=null
 private val busy=AtomicBoolean(false)
 private val rounds=LinkedHashSet<String>()
 private val ocr by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int {
  if(android.os.Build.VERSION.SDK_INT>=26) { val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager; nm.createNotificationChannel(NotificationChannel("boom","Aviator Boom Bot",NotificationManager.IMPORTANCE_LOW)) }
  val n=if(android.os.Build.VERSION.SDK_INT>=26) Notification.Builder(this,"boom") else Notification.Builder(this)
  startForeground(7,n.setContentTitle("Aviator Boom Bot").setContentText("Inasoma screen kwa ruhusa yako").setSmallIcon(android.R.drawable.ic_menu_view).build())
  val code=i?.getIntExtra("code",Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
  val data=i.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
  projection=(getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager).getMediaProjection(code,data)
  showPanel(); capture(); return START_NOT_STICKY
 }
 private fun showPanel() {
  if(!android.provider.Settings.canDrawOverlays(this)) return
  panel=TextView(this).apply { text="BOOM BOT\nInasubiri multipliers..."; textSize=12f; setTextColor(-1); setPadding(16,12,16,12); setBackgroundColor(0xE8202020.toInt()) }
  val type=if(android.os.Build.VERSION.SDK_INT>=26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
  val p=WindowManager.LayoutParams(-2,-2,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT).apply { gravity=Gravity.TOP or Gravity.END; x=10; y=130 }
  (getSystemService(WINDOW_SERVICE) as WindowManager).addView(panel,p)
 }
 private fun capture() {
  val m=resources.displayMetrics; reader=ImageReader.newInstance(m.widthPixels,m.heightPixels,PixelFormat.RGBA_8888,2)
  reader!!.setOnImageAvailableListener({ r ->
   val image=r.acquireLatestImage() ?: return@setOnImageAvailableListener
   if(!busy.compareAndSet(false,true)) { image.close(); return@setOnImageAvailableListener }
   try {
    val bmp=image.toBitmapCompat(); image.close()
    ocr.process(InputImage.fromBitmap(bmp,0)).addOnSuccessListener { result ->
     Regex("([0-9]{1,4}([.][0-9]{1,2})?)\\s*x",RegexOption.IGNORE_CASE).findAll(result.text).forEach { rounds.add(it.groupValues[1]+"x") }
     val values=rounds.toList().takeLast(10).reversed()
     val low=rounds.count { (it.dropLast(1).toDoubleOrNull() ?: 0.0)<2.0 }
     panel?.post { panel?.text="BOOM BOT\nRounds: ${rounds.size} • chini ya 2x: $low\n"+values.joinToString("  ")+"\nHistoria tu; si utabiri." }
    }.addOnCompleteListener { bmp.recycle(); busy.set(false) }
   } catch(e:Exception) { image.close(); busy.set(false) }
  },android.os.Handler(mainLooper))
  display=projection?.createVirtualDisplay("BoomCapture",m.widthPixels,m.heightPixels,m.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader?.surface,null,null)
 }
 override fun onDestroy() { display?.release(); reader?.close(); projection?.stop(); panel?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }; ocr.close(); super.onDestroy() }
 override fun onBind(i:Intent?):IBinder?=null
}