# AVIATOR BOOM BOT — Android starter v0.1

Huu ni mradi wa chanzo wa kuanzia wa Android Studio, si APK iliyokwisha kujengwa.

## Kujenga
1. Fungua Android Studio kwenye kompyuta.
2. Chagua Open na uchague folder hii.
3. Ruhusu Gradle kupakua dependencies, kisha Run kwenye simu ya Android 11.
4. Kwenye simu ruhusu Display over other apps.
5. Gusa Anza kusoma screen na ukubali ruhusa ya Android Screen Capture.

## Mipaka
- OCR inaweza kukosea au kurudia multiplier; hii ni prototype inayohitaji majaribio.
- Inasoma kinachoonekana kwenye screen tu; haiunganishi na seva ya BetPawa.
- Android huonyesha ruhusa ya screen capture; hakuna kurekodi kwa siri.
- Matokeo ya zamani hayawezi kuthibitisha multiplier ijayo.
